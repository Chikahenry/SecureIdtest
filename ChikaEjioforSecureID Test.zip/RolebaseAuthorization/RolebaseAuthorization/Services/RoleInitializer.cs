﻿namespace RolebaseAuthorization.Services
{
    public class RoleInitializer
    {
    }
}
