﻿namespace RolebaseAuthorization.Entities
{
    public class Roles
    {
    }
}
