﻿namespace RolebaseAuthorization.Entities
{
    public class ApplicationUser
    {
    }
}
